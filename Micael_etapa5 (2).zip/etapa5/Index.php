<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Formulário de Contato</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="form-container">
    <h2>Formulário de Contato</h2>

    <?php
      if (isset($_GET['sucesso']) && $_GET['sucesso'] === '1') {
        echo '<p class="sucesso">Formulário enviado com sucesso!</p>';
      }
    ?>

    <form action="processar.php" method="post">
      <div class="form-group">
        <label for="nome">Nome</label>
        <input type="text" id="nome" name="nome" required>
      </div>

      <div class="form-group">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" required>
      </div>

      <div class="form-group">
        <label for="telemovel">Número de Telemóvel</label>
        <input type="tel" id="telemovel" name="telemovel" required>
      </div>

      <div class="form-group">
        <label for="descricao">Descrição</label>
        <textarea id="descricao" name="descricao" required></textarea>
      </div>

      <button type="submit" class="submit-btn">Enviar</button>
    </form>
  </div>
</body>
</html>
