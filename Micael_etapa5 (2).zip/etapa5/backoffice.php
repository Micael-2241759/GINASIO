<?php
require 'conexao.php';

$sql = "SELECT * FROM submissoes ORDER BY data_envio DESC";
$resultado = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <title>Backoffice - Submissões</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="form-container">
    <h2>Submissões Recebidas</h2>
    
    <?php if ($resultado->num_rows > 0): ?>
      <table border="1" cellpadding="10" cellspacing="0" style="width:100%">
        <thead>
          <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Email</th>
            <th>Telemóvel</th>
            <th>Descrição</th>
            <th>Data</th>
          </tr>
        </thead>
        <tbody>
          <?php while($linha = $resultado->fetch_assoc()): ?>
            <tr>
              <td><?= $linha['id'] ?></td>
              <td><?= htmlspecialchars($linha['nome']) ?></td>
              <td><?= htmlspecialchars($linha['email']) ?></td>
              <td><?= htmlspecialchars($linha['telemovel']) ?></td>
              <td><?= nl2br(htmlspecialchars($linha['descricao'])) ?></td>
              <td><?= $linha['data_envio'] ?></td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    <?php else: ?>
      <p>Nenhuma submissão encontrada.</p>
    <?php endif; ?>

    <br>
    <a href="index.php">Voltar ao formulário</a>
  </div>
</body>
</html>
