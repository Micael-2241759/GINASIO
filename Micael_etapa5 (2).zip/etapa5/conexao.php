<?php
$host = "localhost";
$usuario = "root";
$senha = ""; 
$bd = "formulario";

$conn = new mysqli($host, $usuario, $senha, $bd);

if ($conn->connect_error) {
  die("Erro na conexão: " . $conn->connect_error);
}
?>
