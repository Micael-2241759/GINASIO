<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
  require 'conexao.php';


  if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
  }


  $nome = $conn->real_escape_string(trim($_POST["nome"]));
  $email = $conn->real_escape_string(trim($_POST["email"]));
  $telemovel = $conn->real_escape_string(trim($_POST["telemovel"]));
  $descricao = $conn->real_escape_string(trim($_POST["descricao"]));

 
  $sql = "INSERT INTO submissoes (nome, email, telemovel, descricao)
          VALUES ('$nome', '$email', '$telemovel', '$descricao')";


  if ($conn->query($sql) === TRUE) {
    
    header("Location: index.php?sucesso=1");
    exit();
  } else {
    
    echo "Erro: " . $conn->error;
  }


  $conn->close();
} else {
 
  header("Location: index.php");
  exit();
}
?>
