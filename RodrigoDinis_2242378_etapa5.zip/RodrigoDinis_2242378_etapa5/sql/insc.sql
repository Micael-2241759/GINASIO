CREATE DATABASE IF NOT EXISTS inscricao;
USE inscricao;

CREATE TABLE IF NOT EXISTS planos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(100),
    descricao TEXT,
    entradas VARCHAR(50),
    preco DECIMAL(5,2)
);

INSERT INTO planos (titulo, descricao, entradas, preco) VALUES
('Plano Básico', 'Ideal para quem quer começar', '1 entrada por dia', 10.00),
('Plano Premium', 'Marcar 2ª aulas por dia', '2 entradas por dia', 18.00),
('Plano VIP', 'Inclui treino com personal trainer', 'Entradas ilimitadas', 25.00);
