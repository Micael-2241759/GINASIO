<?php
$conn = new mysqli("localhost", "root", "", "estgym");

if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

$resultado = $conn->query("SELECT * FROM inscricoes ORDER BY data_registo DESC");
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Painel de Inscrições - ESTGYM</title>
    <style>
        body { background: #000; color: #fff; font-family: Arial; padding: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; background: #111; }
        th, td { border: 1px solid #333; padding: 10px; text-align: left; }
        th { background: #222; color: yellow; }
    </style>
</head>
<body>
    <h1>Painel de Inscrições</h1>
    <table>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Descrição</th>
            <th>Data</th>
            <th>Categoria</th>
            <th>Registado em</th>
        </tr>
        <?php while ($linha = $resultado->fetch_assoc()): ?>
        <tr>
            <td><?= $linha["id"] ?></td>
            <td><?= $linha["nome"] ?></td>
            <td><?= $linha["descricao"] ?></td>
            <td><?= $linha["data"] ?></td>
            <td><?= $linha["categoria"] ?></td>
            <td><?= $linha["data_registo"] ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>

<?php $conn->close(); ?>

