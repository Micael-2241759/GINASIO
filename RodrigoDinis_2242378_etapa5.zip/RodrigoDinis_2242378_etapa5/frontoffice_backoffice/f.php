

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ESTGYM</title>
    <link rel="stylesheet" href="f.css">
</head>
<body>
<header>
    <div class="header-container">
        <a href="backoffice.php">
            <img src="uti2.png" alt="Ícone do utilizador" class="user-icon">
        </a>
    </div>
</header>

    <section id="intro" class="intro">
        <div class="container">
            <img src="logo.png" class="logo" alt="logo">
            <h2>Planos de Inscrição</h2>
            <a href="#planos" class="cta-btn">Escolha seu Plano</a>
        </div>
    </section>

    <section id="planos" class="planos">
        <div class="container">
   
            <h2>Planos de Inscrição</h2>
            <div class="planos-container">
                <div class="plano">
                    <h3>Plano Básico</h3>
                    <p>Ideal para quem quer começar</p>
                    <p>Entrada por dia: 1</p>
                    <p><strong>10€/mês</strong></p>
              
                </div>
                <div class="plano">
                    <h3>Plano Premium</h3>
                    <p>Marcar 2ª aulas por dia</p>
                    <p>Entradas por dia: 2</p>
                    <p><strong>18€/mês</strong></p>
          
                </div>
                <div class="plano">
                    <h3>Plano VIP</h3>
                    <p>Inclui treino com personal trainer</p>
                    <p>Aulas por dia: ilimitadas</p>
                    <p>Entradas por dia: ilimitadas</p>
                    <p><strong>25€/mês</strong></p>
                
                </div>
            </div>

   
            <div class="botao-formulario">
                <a href="#contato" class="cta-btn">Formulário</a>
            </div>
        </div>
    </section>

    <section id="contato" class="contato">
      <section id="contato" class="contato">
    <div class="container">
        <h2>Formulário</h2>
        <form id="contact-form" method="POST" action="processar_formulario.php">
            <label for="nome">Nome:</label>
            <input type="text" id="nome" name="nome" required>

            <label for="descricao">Descrição:</label>
            <textarea id="descricao" name="descricao" required></textarea>

            <label for="data">Data:</label>
            <input type="date" id="data" name="data" required>


            <label for="categoria">Planos:</label>
            <select id="categoria" name="categoria" required>
                <option value="">Selecione...</option>
                <option value="Básico">Básico</option>
                <option value="Premium">Premium</option>
                <option value="Vip">Vip</option>
            </select>

            <button type="submit" class="cta-btn">Enviar</button>
        </form>
    </div>
</section>

    </section>

    <footer>
        <div class="container">
            <p>&copy; 2025 Ginásio ESTGYM. Todos os direitos reservados.</p>
        </div>
    </footer>
</body>
</html>
