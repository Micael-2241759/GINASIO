<?php require_once 'config.php'; ?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Planos de Inscrição - ESTGYM ADMIN</title>
    <link rel="stylesheet" href="backoffice.css">
</head>
<body>

<header class="navbar">
    <div class="navbar-logo">
        <h2>ESTGYM</h2>
    </div>
    <nav class="navbar-menu">
        <ul>
            <li><a href="#">Utilizadores</a></li>
            <li><a href="#">Planos de Inscrição</a></li>
            <li><a href="#">Workshop</a></li>
            <li><a href="#">Nutrição</a></li>
            <li><a href="#">Eventos</a></li>
            <li><a href="#">Galeria</a></li>
            <li><a href="#">Contactos</a></li>
        </ul>
    </nav>
    <div class="admin-info">
        <p><strong>Admin</strong><br>Administrador</p>
    </div>
</header>

<main class="main-content">
    <h1>Planos de Inscrição</h1>
    <button class="add-btn">+ Adicionar</button>
    <input type="text" placeholder="Pesquisar..." class="search-input">

    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Título</th>
                <th>Descrição</th>
                <th>Entradas</th>
                <th>Preço</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = "SELECT * FROM planos";
            $result = $conn->query($sql);

            if ($result->num_rows > 0):
                while ($row = $result->fetch_assoc()):
            ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= $row['titulo'] ?></td>
                    <td><?= $row['descricao'] ?></td>
                    <td><?= $row['entradas'] ?></td>
                    <td><?= number_format($row['preco'], 2) ?> €</td>
                </tr>
            <?php
                endwhile;
            else:
                echo "<tr><td colspan='5'>Sem planos disponíveis.</td></tr>";
            endif;
            ?>
        </tbody>
    </table>
</main>

</body>
</html>
