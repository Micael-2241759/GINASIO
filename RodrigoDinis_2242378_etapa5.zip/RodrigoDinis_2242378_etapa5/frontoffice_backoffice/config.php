<?php
$host = 'localhost'; 
$user = 'root';      
$password = '';      
$dbname = 'inscricao';  
$port = 3306;        

$conn = new mysqli($host, $user, $password, $dbname, $port);


if ($conn->connect_error) {
    die("Erro na conexão à base de dados: " . $conn->connect_error);
}
?>
