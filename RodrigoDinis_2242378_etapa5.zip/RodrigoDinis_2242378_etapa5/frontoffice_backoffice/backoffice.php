
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Planos de Inscrição - ESTGYM ADMIN</title>
    <link rel="stylesheet" href="backoffice.css">
</head>
<body>

<header class="navbar">
    <div class="navbar-logo">
        <h2>ESTGYM</h2>
    </div>
    <nav class="navbar-menu">
        <ul>
            <li><a href="#">Utilizadores</a></li>
            <li><a href="#">Planos de Inscrição</a></li>
            <li><a href="#">Workshop</a></li>
            <li><a href="#">Nutrição</a></li>
            <li><a href="#">Eventos</a></li>
            <li><a href="#">Galeria</a></li>
            <li><a href="#">Contactos</a></li>
        </ul>
    </nav>
    <div class="admin-info">
        <p><strong>Admin</strong><br>Administrador</p>
    </div>
</header>

<main class="main-content">
    <h1>Planos de Inscrição</h1>
    <button class="add-btn">+ Adicionar</button>
    <input type="text" placeholder="Pesquisar..." class="search-input">

    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Título</th>
                <th>Descrição</th>
                <th>Entradas</th>
                <th>Preço</th>
             
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1</td>
                <td>Plano Básico</td>
                <td>Ideal para quem quer começar</td>
                <td>1 entrada por dia</td>
                <td><strong>10,00€</strong></td>
            
                <td>
                    <a href="#"><span class="edit">Editar</span></a>
                    <a href="#"><span class="delete">Apagar</span></a>
                </td>
            </tr>
            <tr>
                <td>2</td>
                <td>Plano Premium</td>
                <td>Marcar 2ª aulas por dia</td>
                <td>2 entradas por dia</td>
                <td><strong>18,00€</strong></td>
<td>
                    <a href="#"><span class="edit">Editar</span></a>
                    <a href="#"><span class="delete">Apagar</span></a>
                </td>
            </tr>
            <tr>
                <td>3</td>
                <td>Plano VIP</td>
                <td>Inclui treino com personal trainer</td>
                <td>Entradas ilimitadas</td>
                <td><strong>25,00€</strong></td>
        
                <td>
                    <a href="#"><span class="edit">Editar</span></a>
                    <a href="#"><span class="delete">Apagar</span></a>
                </td>
            </tr>
        </tbody>
    </table>
</main>

</body>
</html>




