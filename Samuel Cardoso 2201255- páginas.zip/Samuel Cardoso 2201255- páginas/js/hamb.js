function toggleMenu() {
    document.querySelector('.menu').classList.toggle('active');
}