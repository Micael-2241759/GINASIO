<?php
session_start();
if (isset($_SESSION["aluno_id"])) {
  header("Location: painel.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login - ESTGym</title>
  <link rel="stylesheet" href="css/login.css" />
</head>
<body>
  <div class="login-container">
    <h2>Área do Cliente - <br> <span>ESTGym</span></h2>

    <form method="POST" action="verificar_login.php">
      <label for="email">Email:</label>
      <input type="email" name="email" required />

      <label for="password">Password:</label>
      <input type="password" name="password" required />

      <button type="submit">Entrar</button>
    </form>

    <div class="register-link">
      Não tens conta? <a href="criar_conta.php">Cria uma aqui</a>
    </div>
  </div>
</body>
</html>
