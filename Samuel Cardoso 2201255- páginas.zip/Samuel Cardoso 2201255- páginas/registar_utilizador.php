<?php
// Cria uma ligação à base de dados
$ligacao = new mysqli("localhost", "root", "", "estgym");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  // recolhe os dados do formulário
  $nome = $_POST["nome"];
  $email = $_POST["email"];
  $password = password_hash($_POST["password"],PASSWORD_DEFAULT);


  // Verifica se já existe email
  $verificar = $ligacao->prepare("SELECT id FROM alunos WHERE email = ?");
  $verificar->bind_param("s", $email);
  $verificar->execute();
  $verificar->store_result();

  if ($verificar->num_rows > 0) {
    // Se o email já existe, mostra uma mensagem de erro
    echo "<p style='color:red;'>Este email já está registado. <a href='login.php'>Faz login</a></p>";
  } else {
    // caso contrário, insere o novo utilizador na base de dados
    $stmt = $ligacao->prepare("INSERT INTO alunos (nome, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $nome, $email, $password);
    $stmt->execute();
    $stmt->close();

    //Redireciona para a página de login
    header("Location: login.php");
    exit();
  }
}
?>