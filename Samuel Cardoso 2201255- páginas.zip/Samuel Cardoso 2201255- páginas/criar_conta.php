<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Criar Conta - ESTGym</title>
  <link rel="stylesheet" href="css/login.css" />
</head>
<body>
  <div class="login-box">
    <h2>Cria a Tua Conta -<br> <span style="color: #ffc400;">ESTGym</span></h2>

    <form method="POST" action="registar_utilizador.php">
      <label for="nome">Nome:</label>
      <input type="text" id="nome" name="nome" required />

      <label for="email">Email:</label>
      <input type="email" id="email" name="email" required />

      <label for="password">Password:</label>
      <input type="password" id="password" name="password" required />

      <button type="submit">Criar Conta</button>
    </form>
    <p class="login-link">
  Já tens conta?
  <a href="login.php">Faz login aqui</a>
</p>
  </div>
</body>
</html>
