<?php
session_start();
session_unset(); // Limpa todas as variáveis de sessão
session_destroy(); // Termina a sessão
header("Location: workshop.php"); // Redireciona para o login
exit();
?>
