<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Document</title>
  <link rel="stylesheet" href="css/footer2.css" />
  <link rel="stylesheet" href="css/Workshop.css" />
  <link rel="stylesheet" href="css/nav.css" />
</head>

<body>
<?php
$ligacao = new mysqli("localhost", "root", "", "estgym");

// MARCAR COMO COMPLETO
if (isset($_POST['marcar_completo'])) {
  $id = $_POST['workshop_id'];
  $ligacao->query("UPDATE workshops SET completo = 1 WHERE id = $id");
}

// ELIMINAR
if (isset($_POST['eliminar'])) {
  $id = $_POST['workshop_id'];
  $ligacao->query("UPDATE workshops SET eliminado = 1 WHERE id = $id");
}

// INSERIR NOVO WORKSHOP
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["nome"])) {
  $nome = $_POST["nome"];
  $descricao = $_POST["descricao"];
  $data = $_POST["data"];
  $treinador_id = $_POST["treinador"];
  $categoria_id = $_POST["categoria"];

  $sql = "INSERT INTO workshops (nome, descricao, data, treinador_id, categoria_id)
          VALUES (?, ?, ?, ?, ?)";
  $stmt = $ligacao->prepare($sql);
  $stmt->bind_param("sssii", $nome, $descricao, $data, $treinador_id, $categoria_id);
  $stmt->execute();
  $stmt->close();
  header("Location: Workshop.php");
  exit();
}
?>

<?php
session_start();
?>

  <!-- Navbar/Header -->
  <nav>
    <a href="Galeria.html" class="logo">
      <img src="Logotipo escolhido/ESTG.png" alt="ESTGym Logo" />
    </a>

    <label for="menu-toggle" class="burger">
      <span></span>
      <span></span>
      <span></span>
    </label>
    <input type="checkbox" id="menu-toggle" hidden />

    <!-- Menu para Desktop -->
    <div class="nav-links">
      <a href="inicio.html">Início</a>
      <a href="programas.html">Programas</a>
      <a href="treinadores.html">Treinadores</a>
      <a href="sobre.html">Sobre</a>
      <a href="contactos.html">Contactos</a>
    </div>
    <?php if (isset($_SESSION["aluno_nome"])): ?>
  <div class="user-info">
    <?php echo htmlspecialchars($_SESSION["aluno_nome"]); ?>
    <a href="logout.php" class="logout-btn">(Logout)</a>
  </div>
<?php else: ?>
  <a href="login.php" class="cta">Junta-te Agora</a>
<?php endif; ?>



    <!-- Menu para Telemóvel -->
    <div class="mobile-menu">
      <a href="inicio.html">Início</a>
      <a href="programas.html">Programas</a>
      <a href="treinadores.html">Treinadores</a>
      <a href="sobre.html">Sobre</a>
      <a href="contactos.html">Contactos</a>
      <a href="junta-te.html" class="cta">Junta-te Agora</a>
    </div>
  </nav>

  <section class="hero-section" id="novo-workshop">
  <div class="overlay">
    <div class="hero-content" data-aos="fade-up">
      <h1>Cria o Próximo Grande Evento do ESTGym!</h1>
      <p>Ajuda a transformar vidas através de eventos inesquecíveis.</p>
    </div>
  </div>
</section>

<section class="section" id="exemplos-workshops"> ... </section>
<section class="section" id="beneficios-workshops"> ... </section>

<section id="formulario-adicionar" class="special-section">
  <div class="form-header" data-aos="fade-up">
    <h2>🚀 Cria o Teu Próprio Evento!</h2>
    <p>Adiciona um novo workshop que vai desafiar e inspirar os nossos atletas.</p>
  </div>

  <form class="workshop-form" action="#" method="POST" data-aos="fade-up">
    <div class="form-group">
      <label for="nome">Nome do Workshop:</label>
      <input type="text" id="nome" name="nome" required />
    </div>

    <div class="form-group">
      <label for="descricao">Descrição:</label>
      <textarea id="descricao" name="descricao" rows="4" required></textarea>
    </div>

    <div class="form-group">
      <label for="data">Data:</label>
      <input type="date" id="data" name="data" required />
    </div>

    <div class="form-group">
      <label for="treinador">Treinador Responsável:</label>
      <select name="treinador" id="treinador" required>
        <?php
        $treinadores = $ligacao->query("SELECT id, nome FROM treinadores");
        while ($t = $treinadores->fetch_assoc()) {
          echo "<option value='{$t['id']}'>{$t['nome']}</option>";
        }
        ?>
      </select>
    </div>

      <label for="categoria">Categoria:</label>
      <select name="categoria" id="categoria">
        <option value="1">Yoga</option>
        <option value="2">Treino Funcional</option>
        <option value="3">Resistência</option>
      </select>

      <button type="submit" class="btn">Adicionar Workshop</button>
    </form>
  </section>

  <section class="cta-final">
    <h2 data-aos="zoom-in">Pronto para Inspirar e Transformar?</h2>
    <a href="#formulario-adicionar" class="btn">Vamos Criar!</a>
  </section>

  <section class="section">
    <h2>Workshops Atuais</h2>
    <div class="workshop-cards">
    <?php
    $result = $ligacao->query("SELECT w.id, w.nome, w.descricao, w.data, t.nome AS treinador, c.nome AS categoria, w.completo
      FROM workshops w
      JOIN treinadores t ON w.treinador_id = t.id
      JOIN categorias c ON w.categoria_id = c.id
      WHERE w.eliminado = 0");

    while ($w = $result->fetch_assoc()) {
      echo "<div class='card'>";
      echo "<h3>{$w['nome']}</h3>";
      echo "<p><strong>Descrição:</strong> {$w['descricao']}</p>";
      echo "<p><strong>Data:</strong> {$w['data']}</p>";
      echo "<p><strong>Treinador:</strong> {$w['treinador']}</p>";
      echo "<p><strong>Categoria:</strong> {$w['categoria']}</p>";
      echo "<form method='POST' style='margin-top:10px'>";
      echo "<input type='hidden' name='workshop_id' value='{$w['id']}'>";
      if (!$w['completo']) {
        echo "<button name='marcar_completo' class='btn-pequeno'>Marcar como Completo</button>";
      }
      echo "<button name='eliminar' class='btn-pequeno'>Eliminar</button>";
      echo "</form>";
      echo "</div>";
    }
    ?>
    </div>
  </section>


  <footer class="footer">
    <div class="footer-container">
      <div class="footer-section">
        <h3>Informações</h3>
        <p>Sobre Nós</p>
        <p>Política de Privacidade</p>
        <p>Termos de Utilização</p>
      </div>

      <div class="footer-section">
        <h3>Contactos</h3>
        <p>Morada: Morro do Lena | 2411-901 Leiria, Portugal</p>
        <p>Telefone: +351 910 123 456</p>
        <p>Email: estgym@my.ipleiria.pt</p>
      </div>

      <div class="footer-section">
        <h3>Horário de Funcionamento</h3>
        <p>Segunda a Sexta: 09:00 - 22:00</p>
        <p>Sábado: 09:30 - 13:00 e 15:00 - 18:30</p>
        <p>Domingo: Encerrado</p>
      </div>

      <div class="footer-section">
        <h3>Siga-nos</h3>
        <div class="social-links">
          <a href="#" target="_blank" class="instagram">
            <img src="img/insta3.png" alt="Instagram" />
          </a>
          <a href="#" target="_blank" aria-label="WhatsApp">
            <img src="img/whatsapp.png" alt="WhatsApp" />
          </a>
          <a href="#" target="_blank" aria-label="TikTok">
            <img src="img/tiktok.png" alt="TikTok" />
          </a>
        </div>
      </div>
    </div>
    <div class="footer-bottom">
      <p>&copy; 2025 ESTGYM. Todos os direitos reservados.</p>
    </div>
  </footer>
</body>
<script src="js/hamb.js"></script>
</html>