<?php
session_start();// Inicia a sessão
$ligacao = new mysqli("localhost", "root", "", "estgym");

// Recolhe os dados enviados pelo formulário de login
$email = $_POST["email"];
$password = $_POST["password"];

// Prepara a query para buscar o utilizador com o email indicado
$query = "SELECT * FROM alunos WHERE email = ?";
$stmt = $ligacao->prepare($query);
$stmt->bind_param("s", $email);// Associa o parâmetro do email
$stmt->execute();
$resultado = $stmt->get_result();// Guarda o resultado da query

// Verifica se foi exatamente encontrado um utilizador
if ($resultado->num_rows === 1) {
  $aluno = $resultado->fetch_assoc();// Busca os dados do utilizador

   // Verifica se a password inserida corresponde à armazenada (hash)
  if (password_verify($password, $aluno["password"])) {

    // Guarda dados na sessão
    $_SESSION["aluno_id"] = $aluno["id"];
    $_SESSION["aluno_nome"] = $aluno["nome"];

    // Redireciona para a página workshop.php
    header("Location: workshop.php");
    exit();
  }
}

// Se o email não existir ou a password estiver errada, mostra erro
echo "<p style='color:red;'>Login inválido. <a href='login.php'>Tentar novamente</a></p>";
?>