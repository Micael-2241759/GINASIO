//Verifica se o utilizador está autenticado, se não estiver, redireciona para a página de login

<?php
session_start();
if (!isset($_SESSION["aluno_id"])) {
  header("Location: login.php");
  exit();
}
?>